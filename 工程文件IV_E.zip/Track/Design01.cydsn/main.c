#include <project.h>
#include<stdio.h>
#include<stdlib.h>

extern uint8 const CYCODE LCD_Char_1_customFonts[];//载入传统字体

float angle=-90.0;
int   Angle=0;
char temp[20];
char outputStr[30];
char Rotate_Dir[20];
int  PWM_1=7000;
int  PWM_2=7000;
int foward;
uint16 ADCresult1;
uint16 ADCresult2;
uint16 ADCresult3;
char outputStr1[50];
int i;
int P,I,D;
int error,pre_error;
void LCD_Display();//LCD显示
void Rotate_Verification();//旋转确认
void Servo_PWM_1(int m1);
void Servo_PWM_2(int m2);
void RotateDirectionVerify();
void IntToString(char *str, int number)// 由数值变换为字符串的函数
{
    sprintf(str, "%d", number);
}


int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    CyGlobalIntEnable;
    Clock_1_Enable();
    Clock_2_Enable();
    PWM_1_Start();
    PWM_2_Start();
    LCD_Char_1_Start();
    LCD_Char_1_LoadCustomFonts(LCD_Char_1_customFonts);
    ADC_SAR_Seq_1_Start();
    LCD_Char_1_ClearDisplay();
    LCD_Char_1_Position(0,0);
    LCD_Char_1_PrintString("The angle is:");   //显示字符
    ADC_SAR_Seq_1_StartConvert();    //开始AD转换，
    int count=0;
    double Kp=1000,Ki=0,Kd=0; 
    double PID;
    int current_state=0;
    int previous_state=0;
    int state_control=0;
    for(;;)
    {    
        // Place your application code here. 
        ADC_SAR_Seq_1_IsEndConversion(ADC_SAR_Seq_1_WAIT_FOR_RESULT);//ADC的转换结束，存储结束前一直待机
        ADCresult1 = ADC_SAR_Seq_1_GetResult16(0);//值小于1000为黑，大于1000为白
        ADCresult2 = ADC_SAR_Seq_1_GetResult16(1);
        ADCresult3 = ADC_SAR_Seq_1_GetResult16(2);
        LCD_Char_1_Position(1,13);
        if(ADCresult2<1000)
        {
            current_state=0;
            
          //前进
            
         }   
         if(ADCresult3<1000)//右转
        {
            current_state=1;
            
        }
        if(ADCresult1<1000)//左转
        {   
            current_state=-1;
        
            
        }
        
        if((ADCresult1>1000)&&(ADCresult2>1000)&&(ADCresult3>1000)&&(count<=15))
        {  //全白，后退
            count++;
          
        }

        if((ADCresult1>1000)&&(ADCresult2>1000)&&(ADCresult3>1000)&&(count>=15)){
            count = 0;
            current_state=3;
        }
        if(current_state==3){
            if(previous_state==1)current_state=2;
            else if(previous_state==-1)current_state=-2;
            else if(previous_state==0)current_state=0;
            else current_state=3;
        }
        /*
        error=current_state;
        if(current_state==3){
            foward=-1;
            error=0;
           }
        else foward=1;
        
        P=error;
        I=I+error;
        D=error-pre_error;
        PID=Kp*P+Ki*I+Kd*D;
        switch(foward){
        case 1:Servo_PWM_1(1000+PID);
            Servo_PWM_2(8000-PID);
	        LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("1");
            break;
        case -1:Servo_PWM_1(5100);
            Servo_PWM_2(4000);
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("4");
            CyDelay(50);
            break;
        default:break;
           }
        previous_state=current_state;
        pre_error=error;
        
        */
        switch(current_state){
        case 0:Servo_PWM_1(4500-300);//直行
            Servo_PWM_2(4500+500);
	        LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("0");
            break;
        case 1:Servo_PWM_1(4500-400);   //-400//3700//3900//right
            Servo_PWM_2(4500);//4900(old)
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("1");
            CyDelay(20);
            break;
        case -1:Servo_PWM_1(4500); //4100left
            Servo_PWM_2(4500+500);      //5100
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("-1");
            CyDelay(20);//20
            break;
        case 3:Servo_PWM_1(3800);//back5000
            Servo_PWM_2(4500);
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("3");
            CyDelay(20);
            break;
         case 2:Servo_PWM_1(4500);//右大转
            Servo_PWM_2(3000);//3800
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("2");
            CyDelay(20);//50                               
         case -2:Servo_PWM_1(6000);//左大转//5200
            Servo_PWM_2(4500);
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("-2");
            CyDelay(20);                                 
         default:break;
            }
        previous_state=current_state;
        /*
        /*
        if(((ADCresult1>1000)&&(ADCresult2<1000)&&(ADCresult3<1000))||((ADCresult1>1000)&&(ADCresult2>1000)&&(ADCresult3<1000)))
        {//右转
            Servo_PWM_1(2000);
            Servo_PWM_2(4500);
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("2");
             CyDelay(50);
        }
        if(((ADCresult1<1000)&&(ADCresult2<1000)&&(ADCresult3>1000))||((ADCresult1<1000)&&(ADCresult2>1000)&&(ADCresult3>1000)))
        {//左转
            Servo_PWM_1(4500);
            Servo_PWM_2(5500);
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("3");
             CyDelay(50);
        }
        if((ADCresult1>1000)&&(ADCresult2>1000)&&(ADCresult3>1000))
        {  //全白，后退
            Servo_PWM_1(5000);
            Servo_PWM_2(4000);
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("4");
            CyDelay(20);
        }
        else{
            Servo_PWM_1(4500);
            Servo_PWM_2(6200);
            LCD_Char_1_PrintString("    ");     //输入前清屏
		    LCD_Char_1_Position(1,13);
		    LCD_Char_1_PrintString("5");
        }
        */
    }
    return 0;
}

void LCD_Display()
{
    LCD_Char_1_Position(1,0);
	LCD_Char_1_PrintString("      ");       //输入前清屏        
	LCD_Char_1_Position(1,0);
	sprintf(outputStr,"%d degree",Angle);//显示转的角度
	LCD_Char_1_PrintString(outputStr);

}

void Rotate_Verification()
{
    LCD_Char_1_Position(1,13);
	if(angle < 0)
	{
		LCD_Char_1_PrintString("    ");     //输入前清屏
		LCD_Char_1_Position(1,13);
		LCD_Char_1_PrintString("CW");
	}
	else if(angle > 0)
	{
		LCD_Char_1_PrintString("    ");     //输入前清屏
		LCD_Char_1_Position(1,13);
		LCD_Char_1_PrintString("CCW");
	}
	else
	{
		LCD_Char_1_PrintString("    ");     //输入前清屏
		LCD_Char_1_Position(1,13);
		LCD_Char_1_PrintString("NTR");
	}
  
}

void Servo_PWM_1(int m1)
{
	PWM_1_WriteCompare(m1);          //改变占空比的值
	angle = (90.0*(PWM_1-4500))/2500;  //换算成实际转过的角度,正负值表示逆顺时针转动
    Angle=(int)angle;
}
void Servo_PWM_2(int m2)
{
	PWM_2_WriteCompare(m2);          //改变占空比的值
	angle = (90.0*(PWM_1-4500))/2500;  //换算成实际转过的角度,正负值表示逆顺时针转动
    Angle=(int)angle;
}

