#include "project.h"
#include <stdio.h>
#include<stdlib.h>


void Leftturn();
void Rightturn();
void Go();
void Back();
void IntToString(char *str, int number);


void IntToString(char *str, int number)// 由数值变换为字符串的函数
{
    sprintf(str, "%d", number);
}

void Leftturn()
{
    PWM_1_Start();
    PWM_2_Start();
    PWM_1_WriteCompare(4500+650);
    PWM_2_WriteCompare(4500+650);
}

void Rightturn()
{
    PWM_1_Start();
    PWM_2_Start();
    PWM_1_WriteCompare(4500-650);
    PWM_2_WriteCompare(4500-650);
}

void Go()
{
    PWM_1_Start();
    PWM_2_Start();
    PWM_1_WriteCompare(3727);///左轮。“-100”
    PWM_2_WriteCompare(5500);
}

void Acc()
{
    PWM_1_Start();
    PWM_2_Start();
    PWM_1_WriteCompare(3227-500);///左轮。“-”
    PWM_2_WriteCompare(6000+500);
}

void Back()
{
    PWM_1_Start();
    PWM_2_Start();
    PWM_1_WriteCompare(4500+600+200);///左轮。“-”
    PWM_2_WriteCompare(4500-600);
}



int main(void)
{
    CyGlobalIntEnable;
    LCD_Char_Start();
    
    uint8 ch;
    /* Start SCB UART TX+RX operation */    
    UART_Start();
    UART_UartPutString("CY8CKIT-042 USB-UART\r\n");
    UART_UartPutString("Now,let's begin the travel of PSoc4\r\n");
    
    ch=0xcc;
    for(;;)
    {
        /* Place your application code here. */
        ch=UART_UartGetChar();
        if(ch=='g')
        {
           Go();UART_UartPutChar('g');
        }
         if(ch=='b')
        {
           Back();UART_UartPutChar('b');
        }
         if(ch=='r')
        {
           Rightturn();UART_UartPutChar('r');
        }
         if(ch=='l')
        {
           Leftturn();UART_UartPutChar('l');
        }
        if(ch=='s')
        {
           PWM_1_WriteCompare(4500);PWM_2_WriteCompare(4500);UART_UartPutChar('x');
        }
   
    }
    return 0;

}
